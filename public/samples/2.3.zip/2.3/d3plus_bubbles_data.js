/**
 * Created by Luan on 2015. 12. 27..
 */

var d3plus_bubble_data = [
    {"value": 100, "name": "Google", "group": "Site"},
    {"value": 25, "name": "Naver", "group": "Site"},
    {"value": 12, "name": "Daum", "group": "Site"},
    {"value": 32, "name": "Javascript", "group": "Language"},
    {"value": 12, "name": "C++", "group": "Language"},
    {"value": 28, "name": "C#", "group": "Language"},
    {"value": 30, "name": "JAVA", "group": "Language"},
    {"value": 12, "name": "Redis", "group": "Database"},
    {"value": 8, "name": "Mongo", "group": "Database"},
    {"value": 20, "name": "MySQL", "group": "Database"},
]